﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Controls : MonoBehaviour {
	public Button Control;

	void Start () {
		Button btn = Control.GetComponent<Button> ();
		btn.onClick.AddListener (Scene3);
	}


	public void Scene3 () {
		StartCoroutine (FX (1f));

	}
	public IEnumerator FX(float sec) {
		AudioSource audio = GetComponent<AudioSource> ();
		audio.Play();
		yield return new WaitForSeconds (0.75f);
		SceneManager.LoadScene ("Scene3");
	}
}
