﻿using UnityEngine;
using System.Collections;

public class BulletLife : MonoBehaviour {
	public float bulletLife = 1f;
	public GameObject bullet;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		bulletLife -= Time.deltaTime;
		if (bulletLife <= 0) {
			Destroy (gameObject);
		}
	}
	void OnTriggerEnter2D (Collider2D collider) {
		if (collider.gameObject.tag == "Obsticle") {
			Destroy (bullet);
		}
	}
}
