﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayButton : MonoBehaviour {
	public Button Play;
	//public GameObject Gun;

	void Start () {
		Button btn = Play.GetComponent<Button> ();
		btn.onClick.AddListener (Scene2);
	}
	/*void Update() {
		Gun.GetComponent<GunSpawning> ().gun.SetActive (true);
		DestroyImmediate (GameObject.Find("UI"));
		DestroyImmediate (GameObject.Find("PlayerA"));
		DestroyImmediate (GameObject.Find("PlayerB"));
		DestroyImmediate (GameObject.Find("GunSpawner"));
		DestroyImmediate (GameObject.Find("Gun"));
	}*/

	public void Scene2 () {
		StartCoroutine (FX (1f));

	}
		public IEnumerator FX(float sec) {
		AudioSource audio = GetComponent<AudioSource> ();
		audio.Play();
		yield return new WaitForSeconds (0.75f);
		SceneManager.LoadScene ("Scene2");
	}
}
