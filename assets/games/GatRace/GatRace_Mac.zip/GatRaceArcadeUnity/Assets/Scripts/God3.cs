﻿using UnityEngine;
using System.Collections;

public class God3 : MonoBehaviour {
	public GameObject god3;
	public static God3 instance;
	public void Awake() {

		DontDestroyOnLoad (god3.gameObject);

		if (instance == null) {
			instance = this;
		} else {
			DestroyObject (god3.gameObject);
		}

	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
