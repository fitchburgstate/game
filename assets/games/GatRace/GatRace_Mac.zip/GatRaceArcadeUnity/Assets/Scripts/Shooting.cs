﻿using UnityEngine;
using System.Collections;

public class Shooting : MonoBehaviour {
	public GameObject bullet;
	public float speed = 1f;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.Space)) {
			GameObject bulletInstance = Instantiate (bullet, transform.position, Quaternion.Euler (new Vector3 (0, 0, 0))) as GameObject;
			bulletInstance.GetComponent<Rigidbody2D> ().velocity = (Vector3.left * speed);
		}
	}
	void OnTriggerEnter (Collider other){
		if (other.gameObject.tag == "Player") {
			Physics.IgnoreCollision (other.GetComponent<Collider> (), other);
		}
	}
}
