﻿using UnityEngine;
using System.Collections;

public class GunSpawning : MonoBehaviour {
	public static GunSpawning instance;
	public GameObject[] spawnPoints;
	public GameObject currentPoint;
	int index;
	public GameObject gun;
	private Vector2 pos;
	public GameObject points;

	/*public void Awake() {

		DontDestroyOnLoad (points.gameObject);

		if (instance == null) {
			instance = this;
		} else {
			DestroyObject (points.gameObject);
		}

	}*/


	public void Start() {
		GunSpawning instance= new GunSpawning() ;
		Invoke ("Respawning", 0f);
	}
	

	public void Spawn () {
		gun.transform.position = currentPoint.transform.position;
		gun.SetActive(true);
	}
	public void Respawning() {
		StartCoroutine (Spawning (1f));
	}
	public IEnumerator Spawning (float sec) {
		gun.SetActive (false);
		index = Random.Range (0, spawnPoints.Length);
		currentPoint = spawnPoints[index];
		print (currentPoint.name);
		//Spawning the Gun
		Invoke("Spawn", 2.5f);
		yield return new WaitForSeconds (sec);
	}

}
