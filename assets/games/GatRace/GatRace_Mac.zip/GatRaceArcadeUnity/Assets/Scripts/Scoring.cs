﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Scoring : MonoBehaviour {
	public GameObject player1;
	public GameObject player2;
	public GameObject UI;
	public static Scoring instanceRef;
	public GameObject Spawner;
	public GameObject p1Spawn;
	public GameObject p2Spawn;

	//score
	public float player1Score;
	public float player2Score;


	//sprites
	public Sprite p1w1;
	public Sprite p1w2;
	public Sprite p1w3;
	public Sprite p2w1;
	public Sprite p2w2;
	public Sprite p2w3;
	public Sprite Bullet0;
	public Sprite Bullet1;
	public Sprite Bullet2;
	public Sprite Bullet3;
	public Sprite Bullet4;
	public Sprite Bullet5;
	public Sprite Bullet6;

	//UI Images
	public Image P1W1;
	public Image P1W2;
	public Image P1W3;
	public Image P2W1;
	public Image P2W2;
	public Image P2W3;
	public Image P1BulletCount;
	public Image P2BulletCount;

	//Win Condition
	public bool p1Win = false;
	public bool p2Win = false;
	public Text Win;
	public Text Enter;
	public bool Flashing = false;

	public GameObject god;

	/*public void Awake() {
		if ((p1Win == false) || (p2Win == false)) {
			DontDestroyOnLoad (UI.gameObject);

			if (instanceRef == null) {
				instanceRef = this;
			} else {
				DestroyObject (UI.gameObject);
			}
		} else {
			DestroyImmediate (UI.gameObject);
		}

	}*/



	void Start () {
		player1 = GameObject.Find("PlayerA");
		player2 = GameObject.Find("PlayerB");
		p1Spawn = GameObject.Find ("PlayerASpawn");
		p2Spawn = GameObject.Find ("PlayerBSpawn");
		god = GameObject.Find ("God");
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		
		//Win 1
		if (player1Score == 1) {
			P1W1.GetComponent<Image> ().sprite= p1w1;
		}
		if (player2Score == 1) {
			P2W1.GetComponent<Image> ().sprite= p2w2;
		}
		//Win2
		if (player1Score == 2) {
			P1W2.GetComponent<Image> ().sprite= p1w2;
		}
		if (player2Score == 2) {
			P2W2.GetComponent<Image> ().sprite= p2w2;
		}
		//Win 3
		if (player1Score == 3) {
			P1W3.GetComponent<Image> ().sprite= p1w3;
		}
		if (player2Score == 3) {
			P2W3.GetComponent<Image> ().sprite= p2w3;
		}
		//Winning

		if (player1Score == 3){
			p1Win = true;
		}
		if (player2Score == 3){
			p2Win = true;
		}
		if (p1Win == true) {
			Win.GetComponent<Text> ().text = ("Player 1 is the Winner!");
		}
		if (p2Win == true) {
			Win.GetComponent<Text> ().text = ("Player 2 is the Winner!");
		}
		if ((p1Win == true) || (p2Win == true)) {
			StartCoroutine( FlashingText ( 1f));
		}
		if ((Flashing = true) &&((p1Win == true) || (p2Win == true)) && (Input.GetKey ("1"))) {
			Destroy (god);
			SceneManager.LoadScene ("Scene1");
		}

	
		//Resetting the Game
		if (((p1Win == false) && (p2Win == false) && ((player2.GetComponent<Player2Controller>().isDead == true) || (player1.GetComponent<PlayerController>().isDead == true)))) {
			p1Spawn = GameObject.Find ("PlayerASpawn");
			p2Spawn = GameObject.Find ("PlayerBSpawn");
			StartCoroutine (Reset (2f));
		}

		// Changing Bullet Sprite

		//Player1
		if (player1.GetComponent<PlayerController> ().bulletCount == 6) {
			P1BulletCount.GetComponent<Image>().sprite= Bullet6;
		}
		if (player1.GetComponent<PlayerController> ().bulletCount == 5) {
			P1BulletCount.GetComponent<Image>().sprite = Bullet5;
		}
		if (player1.GetComponent<PlayerController> ().bulletCount == 4) {
			P1BulletCount.GetComponent<Image>().sprite = Bullet4;
		}
		if (player1.GetComponent<PlayerController> ().bulletCount == 3) {
			P1BulletCount.GetComponent<Image>().sprite = Bullet3;
		}
		if (player1.GetComponent<PlayerController> ().bulletCount == 2) {
			P1BulletCount.GetComponent<Image>().sprite = Bullet2;
		}
		if (player1.GetComponent<PlayerController> ().bulletCount == 1) {
			P1BulletCount.GetComponent<Image>().sprite = Bullet1;
		}
		if (player1.GetComponent<PlayerController> ().bulletCount == 0) {
			P1BulletCount.GetComponent<Image>().sprite = Bullet0;
		}
		//Player2
		if (player2.GetComponent<Player2Controller> ().bulletCount == 6) {
			P2BulletCount.GetComponent<Image>().sprite = Bullet6;
		}
		if (player2.GetComponent<Player2Controller> ().bulletCount == 5) {
			P2BulletCount.GetComponent<Image>().sprite = Bullet5;
		}
		if (player2.GetComponent<Player2Controller> ().bulletCount == 4) {
			P2BulletCount.GetComponent<Image>().sprite = Bullet4;
		}
		if (player2.GetComponent<Player2Controller> ().bulletCount == 3) {
			P2BulletCount.GetComponent<Image>().sprite = Bullet3;
		}
		if (player2.GetComponent<Player2Controller> ().bulletCount == 2) {
			P2BulletCount.GetComponent<Image>().sprite = Bullet2;
		}
		if (player2.GetComponent<Player2Controller> ().bulletCount == 1) {
			P2BulletCount.GetComponent<Image>().sprite = Bullet1;
		}
		if (player2.GetComponent<Player2Controller> ().bulletCount == 0) {
			P2BulletCount.GetComponent<Image>().sprite = Bullet0;
		}
	}
	public IEnumerator Reset (float sec) {
		yield return new WaitForSeconds (sec);
		P1BulletCount.GetComponent<Image> ().sprite = Bullet6;
		P2BulletCount.GetComponent<Image> ().sprite = Bullet6;
		player1.GetComponent<PlayerController> ().isDead = false;
		player1.GetComponent<PlayerController> ().notDead = true;
		player1.GetComponent<PlayerController> ().stayFrosty = false;
		player1.GetComponent<PlayerController> ().canScore = true;
		player1.GetComponent<PlayerController> ().bulletCount = 6;
		player1.GetComponent<SpriteRenderer> ().sprite = player1.GetComponent<PlayerController> ().noGun;
		player2.GetComponent<Player2Controller> ().isDead = false;
		player2.GetComponent<Player2Controller> ().notDead = true;
		player2.GetComponent<Player2Controller> ().stayFrosty = false;
		player2.GetComponent<Player2Controller> ().canScore = true;
		player2.GetComponent<Player2Controller> ().bulletCount = 6;
		player2.GetComponent<SpriteRenderer> ().sprite = player2.GetComponent<Player2Controller> ().noGun;
		player1.transform.position = p1Spawn.transform.position;
		player2.transform.position = p2Spawn.transform.position;
		player1.transform.rotation = p1Spawn.transform.rotation;
		player2.transform.rotation = p2Spawn.transform.rotation;
		StartCoroutine (GunRespawn (1f));
		SceneManager.LoadScene("Scene2");
	}
	private IEnumerator GunRespawn (float sec) {
		//print ("Does this bullshit work?");
		Spawner.GetComponent<GunSpawning> ().Respawning();
		yield return new WaitForSeconds (sec);
	}
	public IEnumerator FlashingText (float sec){
		yield return new WaitForSeconds (.75f);
		Enter.GetComponent<Text> ().text = ("Press P1 to Return to the Main Menu!");
		Flashing = true;
	}
}
