﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuitGame : MonoBehaviour {

	void Start() {
		Cursor.visible = false;
	}


	void Update () {
		if (Input.GetButton ("Quit"))
			Application.Quit ();
	}
}
