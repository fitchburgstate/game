﻿using UnityEngine;
using System.Collections;

public class Player2Controller : MonoBehaviour {

	//Movement
	private static Rigidbody2D rb;
	private float movex;
	private float movey;
	public bool notDead;


	[Range(0.0f, 10.0f)]
	public float speed;
	[Range(0.0f, 1000.0f)]
	public float rotationSpeed;
	//Game Objects
	public GameObject playerA;
	public GameObject playerB;
	public GameObject gun;
	public GameObject bulletSpawn;
	public GameObject whip;
	public GameObject whipFX;
	public GameObject Spawner;
	public GameObject scoring;
	//public GameObject PlayerBSpawn;
	public static Player2Controller instance;
	public GameObject gunPickup;

	//Shooting
	public GameObject bullet;
	public float bulletSpeed = .5f;
	public bool stayFrosty = false;
	public float whipCD = .5f;
	public float bulletCount;
	public float shootCD;


	//SpriteChanging
	public Sprite noGun;
	public Sprite hasGun;
	public Sprite whiping;
	public Sprite dead;

	//Scoring
	public float score = 0f;
	public bool isDead;
	public bool canScore = true;

	/*void Awake () {
		DontDestroyOnLoad (playerB.gameObject);

		if (instance == null) {
			instance = this;
		} else {
			DestroyObject (playerB.gameObject);
		}
	}*/

	// Use this for initialization
	void Start () {
		GetComponent<SpriteRenderer> ().sprite = noGun;
		rb = playerB.GetComponent<Rigidbody2D> ();
		notDead = true;
		isDead = false;
	}

	void Update () {
		shootCD += Time.deltaTime;
	}

	// Update is called once per frame
	void FixedUpdate () {

		//Movement
		if (notDead == true) {
			movex = Input.GetAxisRaw ("Horizontal1");
			movey = Input.GetAxisRaw ("Vertical1");
			var move =  new Vector3 (movex, movey, 0);
			rb.transform.position += move.normalized * speed * Time.deltaTime;
			if (Input.GetButton("RotateLP2"))
				transform.Rotate(Vector3.forward * rotationSpeed * Time.deltaTime);

			if (Input.GetButton("RotateRP2"))
				transform.Rotate(-Vector3.forward * rotationSpeed * Time.deltaTime);

			if (Input.GetButtonDown ("FireP2") && (stayFrosty == true) && (bulletCount > 0) && (shootCD >= 0.01f)) {
				GameObject bulletInstance = Instantiate (bullet, bulletSpawn.transform.position, playerB.transform.rotation) as GameObject;
				bulletInstance.GetComponent<Rigidbody2D> ().AddForce(transform.up * bulletSpeed);
				bulletCount -= 1;
				shootCD = 0;
				GunShot ();
			}

			if (bulletCount == 0) {
				stayFrosty = false;
				GetComponent<SpriteRenderer> ().sprite = noGun;
				GunSpawning instance = new GunSpawning ();
				gun.transform.position = Spawner.GetComponent<GunSpawning>().currentPoint.transform.position;
				gun.SetActive (true);
				StartCoroutine (GunRespawn (1f));
				bulletCount = 6;
			}

			whipCD += Time.deltaTime;
			if (Input.GetButtonDown ("FireP2") && (whipCD >= .5f) && (stayFrosty == false) ){

				StartCoroutine (Whip (0.3f));
			}
		}
	}

	private  IEnumerator Whip(float sec) {

		GetComponent<SpriteRenderer> ().sprite = whiping;
		GameObject whipInstance = Instantiate (whip, whipFX.transform.position, whipFX.transform.rotation) as GameObject;
		whipCD = 0f;
		WhipSound ();
		yield return new WaitForSeconds (sec);
		if (stayFrosty == false) {
			GetComponent<SpriteRenderer> ().sprite = noGun;
		}
		if (stayFrosty == true) {
			GetComponent<SpriteRenderer> ().sprite = hasGun;
		}
	}


	//Grabbing the Gun
	void OnTriggerEnter2D (Collider2D collider) {
		if ((collider.gameObject.tag == "Gun") && (stayFrosty == false)) {
			//gun.transform.parent = player.transform;
			gun.SetActive(false);
			GunPickup ();
			print ("Got It!");
			stayFrosty = true;
			bulletCount = 6;
			GetComponent<SpriteRenderer> ().sprite = hasGun;
		}
		if (collider.gameObject.tag == "PlayerB") {
			Physics.IgnoreCollision(bullet.GetComponent<Collider>(), playerB.GetComponent<Collider>());
		}
		if ((collider.gameObject.tag == "Bullet") && (notDead == true)) {
			print("Player 2 is Dead!");
			GetComponent<SpriteRenderer> ().sprite = dead;
			notDead = false;
			isDead = true;
			DeathSound ();
			if ((scoring.GetComponent<Scoring> ().player1Score == 0) && (canScore == true)) {
				Invoke ("ScoreSet4", 0f);
			} else if ((scoring.GetComponent<Scoring> ().player1Score == 1) && (canScore == true)) {
				Invoke ("ScoreSet5", 0f);
			} else if ((scoring.GetComponent<Scoring> ().player1Score == 2) && (canScore == true)) {
				Invoke ("ScoreSet6", 0f);
			}
		}
		if (collider.gameObject.tag == "Whip") {
			StartCoroutine (Stun (1.5f));
			if (stayFrosty == true) {
				stayFrosty = false;
				GetComponent<SpriteRenderer> ().sprite = noGun;
				GunSpawning instance = new GunSpawning ();
				gun.transform.position = Spawner.GetComponent<GunSpawning>().currentPoint.transform.position;
				gun.SetActive (true);
				StartCoroutine(GunRespawn(1f));
			}
		}
	}
	private IEnumerator Stun (float sec) {
		notDead = false;
		yield return new WaitForSeconds (sec);
		notDead = true;
	}
	private IEnumerator GunRespawn (float sec) {
		print ("Does this bullshit work?");
		Spawner.GetComponent<GunSpawning> ().Respawning();
		yield return new WaitForSeconds (sec);
	}
	public void ScoreSet4 () {
		scoring.GetComponent<Scoring> ().player1Score = 1;
		canScore = false;
	}
	public void ScoreSet5 () {
		scoring.GetComponent<Scoring> ().player1Score = 2;
		canScore = false;
	}
	public void ScoreSet6 () {
		scoring.GetComponent<Scoring> ().player1Score = 3;
		canScore = false;
	}
	public void WhipSound () {
		AudioSource whipSound = whipFX.GetComponent<AudioSource> ();
		whipSound.Play();
	}
	public void GunShot (){
		AudioSource shoot = bulletSpawn.GetComponent<AudioSource> ();
		shoot.Play();
	}
	public void DeathSound () {
		AudioSource deadSound = playerA.GetComponent<AudioSource> ();
		deadSound.Play ();
	}
	public void GunPickup() {
		AudioSource pickup = gunPickup.GetComponent<AudioSource> ();
		pickup.Play ();
	}
}
