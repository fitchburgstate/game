﻿using UnityEngine;
using System.Collections;

public class God2 : MonoBehaviour {
	public GameObject god2;
	public static God2 instance;
	public void Awake() {

		DontDestroyOnLoad (god2.gameObject);

		if (instance == null) {
			instance = this;
		} else {
			DestroyObject (god2.gameObject);
		}

	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
