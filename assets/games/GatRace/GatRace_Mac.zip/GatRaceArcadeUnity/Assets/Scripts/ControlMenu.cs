﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ControlMenu : MonoBehaviour {
	public Button Back;

	void Start () {
		Button btn = Back.GetComponent<Button> ();
		btn.onClick.AddListener (Scene1);
	}


	public void Scene1 () {
		StartCoroutine (FX (1f));

	}
	public IEnumerator FX(float sec) {
		AudioSource audio = GetComponent<AudioSource> ();
		audio.Play();
		yield return new WaitForSeconds (0.75f);
		SceneManager.LoadScene ("Scene1");
	}
}
