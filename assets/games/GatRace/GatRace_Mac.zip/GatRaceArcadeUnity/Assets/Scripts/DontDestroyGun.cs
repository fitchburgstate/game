﻿using UnityEngine;
using System.Collections;

public class DontDestroyGun : MonoBehaviour {
	public static DontDestroyGun instance;
	public GameObject gun;


	public void Awake() {

		DontDestroyOnLoad (gun.gameObject);

		if (instance == null) {
			instance = this;
		} else {
			DestroyObject (gun.gameObject);
		}

	}

	// Use this for initialization
	void Start () {
	
	}

	// Update is called once per frame
	void Update () {
	
	}
}
